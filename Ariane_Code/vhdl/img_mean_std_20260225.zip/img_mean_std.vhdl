
library IEEE;

use IEEE.std_logic_1164.all;
use IEEE.NUMERIC_STD.ALL;

entity img_mean_std is
port (
    ClkxCI          : in std_logic;
    ResetxRI        : in std_logic;
    PixValxDI       : in std_logic_vector(15 downto 0);
    FrameValidxSI   : in std_logic;
    LineValidxSI    : in std_logic;

    PixSumxDO       : out std_logic_vector(31 downto 0);
    PixSqSumxDO     : out std_logic_vector(31 downto 0);
    PDatValidxSO    : out std_logic
);
end img_mean_std;
architecture architecture_img_mean_std of img_mean_std is

    constant TILE_SIZE_X : integer := 16;
    constant TILE_SIZE_Y : integer := 16;
    constant N_TILES_X : integer := 640/TILE_SIZE_X;
    constant MEAN_DARK_VAL : integer := 55;

    type tile_mem_type is array (0 to N_TILES_X-1) of std_logic_vector(31 downto 0);
    signal SumMemxDP : tile_mem_type;
    signal SumSqMemxDP : tile_mem_type;
    signal SumRegxDP, SumRegxDN : unsigned(31 downto 0);
    signal SumSqRegxDP, SumSqRegxDN : unsigned(31 downto 0);

    signal PDatValidxSP, PDatValidxSN : std_logic;
    
    
    signal WrAddrxD : integer range 0 to N_TILES_X-1;
    signal RdAddrxD : integer range 0 to N_TILES_X-1;
    signal SumMemOutxDP : std_logic_vector(31 downto 0);
    signal SumSqMemOutxDP : std_logic_vector(31 downto 0);
    signal MemWrEnxS : std_logic;
    signal SumMemInxD : std_logic_vector(31 downto 0);
    signal SumSqMemInxD : std_logic_vector(31 downto 0);
    
    signal FrameValidLastxSP, FrameValidLastxSN : std_logic; 
    signal LineValidLastxSP, LineValidLastxSN : std_logic;

    signal PixCntxDP, PixCntxDN : integer range 0 to TILE_SIZE_X-1;
    signal TileCntxDP, TileCntxDN : integer range 0 to N_TILES_X-1;
    signal LineCntxDP, LineCntxDN : integer range 0 to TILE_SIZE_Y-1;

    -- input registers / pre-compute
    signal PixValPrexDP, PixValPrexDN : unsigned(PixValxDI'range);
    signal FrameValidPrexSP, FrameValidPrexSN : std_logic;
    signal LineValidPrexSP, LineValidPrexSN : std_logic;
    
    signal PixValxDP, PixValxDN : unsigned(PixValxDI'range);
    signal FrameValidxSP, FrameValidxSN : std_logic;
    signal LineValidxSP, LineValidxSN : std_logic;
    signal PixValSqxDP, PixValSqxDN : unsigned((1+2*PixValxDI'high) downto 0);


begin
   -- architecture body
    p_memzing : process (ClkxCI, ResetxRI, MemWrEnxS)
	begin
		if (ResetxRI = '1') then
            FrameValidLastxSP <= '0';
            LineValidLastxSP <= '0';
            FrameValidxSP <= '0';
            LineValidxSP <= '0';
            FrameValidPrexSP <= '0';
            LineValidPrexSP <= '0';
            PixCntxDP <= 0;
            TileCntxDP <= 0;
            LineCntxDP <= 0;
            SumRegxDP <= (others => '0');
            SumSqRegxDP <= (others => '0');
            PDatValidxSP <= '0';
		elsif (rising_edge(ClkxCI)) then
            FrameValidLastxSP <= FrameValidLastxSN;
            LineValidLastxSP <= LineValidLastxSN;
            FrameValidxSP <= FrameValidxSN;
            LineValidxSP <= LineValidxSN;
            FrameValidPrexSP <= FrameValidPrexSN;
            LineValidPrexSP <= LineValidPrexSN;
            PixCntxDP <= PixCntxDN;
            TileCntxDP <= TileCntxDN;
            LineCntxDP <= LineCntxDN;
            SumRegxDP <= SumRegxDN;
            SumSqRegxDP <= SumSqRegxDN;
            PDatValidxSP <= PDatValidxSN;
		end if;
        
        if (rising_edge(ClkxCI)) then
            if MemWrEnxS = '1' then
                SumMemxDP(WrAddrxD) <= SumMemInxD;
                SumSqMemxDP(WrAddrxD) <= SumSqMemInxD;
            end if;
            SumMemOutxDP <= SumMemxDP(RdAddrxD);
            SumSqMemOutxDP <= SumSqMemxDP(RdAddrxD);
            PixValPrexDP <= PixValPrexDN;
            PixValxDP <= PixValxDN;
            PixValSqxDP <= PixValSqxDN;
        end if;
	end process;
    
    -- input registers / pre-compute
    PixValPrexDN <= unsigned(PixValxDI) - to_unsigned(MEAN_DARK_VAL, PixValxDI'length);
    FrameValidPrexSN <= FrameValidxSI;
    LineValidPrexSN <= LineValidxSI;
    
    PixValxDN <= PixValPrexDP;
    FrameValidxSN <= FrameValidPrexSP;
    LineValidxSN <= LineValidPrexSP;
    PixValSqxDN <= PixValPrexDP * PixValPrexDP;
        
    FrameValidLastxSN <= FrameValidxSP;
    LineValidLastxSN <= LineValidxSP;

    PDatValidxSO <= PDatValidxSP;

    SumMemInxD <= std_logic_vector(SumRegxDP + PixValxDP);
    SumSqMemInxD <= std_logic_vector(SumSqRegxDP + PixValSqxDP);
    WrAddrxD <= TileCntxDP;
    RdAddrxD <= 0 when TileCntxDP = N_TILES_X-1 else TileCntxDP + 1;

    PixSumxDO <= std_logic_vector(SumRegxDP);
    PixSqSumxDO <= std_logic_vector(SumSqRegxDP);
   
    p_memless : process(PixCntxDP, TileCntxDP, LineCntxDP, SumRegxDP, PixValxDP, SumSqRegxDP,  PixValSqxDP, 
        FrameValidxSP, FrameValidLastxSP, LineValidxSP, LineValidLastxSP, SumMemOutxDP, SumSqMemOutxDP)
    begin
        PixCntxDN <= PixCntxDP;
        TileCntxDN <= TileCntxDP;
        LineCntxDN <= LineCntxDP;

        SumRegxDN <= SumRegxDP + PixValxDP;
        SumSqRegxDN <= SumSqRegxDP + PixValSqxDP;

        MemWrEnxS <= '0';
        PDatValidxSN <= '0';

        if FrameValidxSP = '0' then
            -- outside of frame, reset counters
            PixCntxDN <= 0;
            TileCntxDN <= N_TILES_X-1;
            LineCntxDN <= 0;
        else
            if FrameValidLastxSP = '0' then
                -- new frame started
                -- send frame header
                PDatValidxSN <= '1';
                SumRegxDN <= to_unsigned(1000,32);
                SumSqRegxDN <= to_unsigned(1000,32);
            end if;

            if LineValidxSP = '1' then
                if LineValidLastxSP = '0' then
                    -- special handling for first tile in line
                    TileCntxDN <= 0;
                end if;
                if PixCntxDP = 0 then
                    PixCntxDN <= PixCntxDP +1;
                    if LineCntxDP = 0 then
                        -- first pixel in tile, reset sums
                        SumRegxDN(PixValxDP'high downto 0) <= PixValxDP;
                        SumRegxDN(SumRegxDN'high downto PixValxDP'high+1) <= (others => '0');
                        SumSqRegxDN <= PixValSqxDP;
                    else
                        -- not first line, load partial sums from memory
                        SumRegxDN <= unsigned(SumMemOutxDP) + PixValxDP;
                        SumSqRegxDN <= unsigned(SumSqMemOutxDP) + PixValSqxDP;
                    end if;
                elsif PixCntxDP = TILE_SIZE_X-1 then
                    -- last pixel in tile for this line
                    PixCntxDN <= 0;
                    if TileCntxDP < N_TILES_X-1 then
                        TileCntxDN <= TileCntxDP + 1;
                    end if;
                    MemWrEnxS <= '1';
                    if LineCntxDP = TILE_SIZE_Y-1 then
                        -- last pixel in tile overall
                        -- output result to next stage
                        PDatValidxSN <= '1';
                    end if; 
                else
                    PixCntxDN <= PixCntxDP +1;
                end if; 
            else
                if LineValidLastxSP = '1' then
                    -- just finished reading a line
                    if LineCntxDP = TILE_SIZE_Y-1 then
                        LineCntxDN <= 0;
                    else
                        LineCntxDN <= LineCntxDP+1;
                    end if;
                end if;
                PixCntxDN <= 0;
                TileCntxDN <= N_TILES_X-1;
            end if;

        end if;

    end process;
   
end architecture_img_mean_std;
